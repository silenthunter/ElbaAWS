#!/bin/bash
cd .
CURRENT_PATH=`pwd`
source set_elba_env.sh
ssh $CONTROL_HOST mkdir -p $OUTPUT_HOME
scp -rp $CURRENT_PATH/* $CONTROL_HOST:$OUTPUT_HOME/
