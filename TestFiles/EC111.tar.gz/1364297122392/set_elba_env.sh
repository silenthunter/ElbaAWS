
#!/bin/bash

set -o allexport

# HOSTS
CONTROL_HOST=node1
BENCHMARK_HOST=node2
CLIENT1_HOST=node3
CLIENT2_HOST=node4
CLIENT3_HOST=node5
CLIENT4_HOST=node6
HTTPD_HOST=node7
TOMCAT1_HOST=node8
MYSQL1_HOST=node9




# All parameters from the configuration
RUBBOS_RESULTS_DIR_NAME=2013-03-26T072522-0400
EMULAB_EXPERIMENT_NAME=ElbaTest
WORK_HOME=/home/ec2-user/test/
OUTPUT_HOME=/home/ec2-user/test/rubbosMulini6/output
SOFTWARE_HOME=/home/ec2-user/Test_software
DATA_HOME=/home/ec2-user/Test_software
RUBBOS_RESULTS_HOST=node1
RUBBOS_RESULTS_DIR_BASE=/home/ec2-user/results
ELBA_TOP=/mnt/elba
RUBBOS_TOP=$ELBA_TOP/rubbos
TMP_RESULTS_DIR_BASE=/mnt/elba/rubbos/results
RUBBOS_HOME=/mnt/elba/rubbos/RUBBoS
SYSSTAT_HOME=/mnt/elba/rubbos/sysstat-7.0.0
HTTPD_HOME=/mnt/elba/rubbos/apache2
HTTPD_INSTALL_FILES=$RUBBOS_TOP/httpd-2.0.54
MOD_JK_INSTALL_FILES=$RUBBOS_TOP/jakarta-tomcat-connectors-1.2.15-src
CATALINA_HOME=/mnt/elba/rubbos/apache-tomcat-5.5.17
CATALINA_BASE=$CATALINA_HOME
MYSQL_HOME=$RUBBOS_TOP/mysql-5.0.51a-linux-i686-glibc23
JONAS_ROOT=$RUBBOS_TOP/JONAS_4_6_6
JAVA_HOME=/mnt/elba/rubbos/jdk1.5.0_07
JAVA_OPTS_DB=-Xmx160m
J2EE_HOME=/mnt/elba/rubbos/j2sdkee1.3.1
ANT_HOME=$RUBBOS_TOP/apache-ant-1.6.5
JAVA_TARBALL=jdk1.5.0_07.tar.gz
J2EE_TARBALL=j2sdkee1.3.1.jar.gz
ANT_TARBALL=apache-ant-1.6.5.tar.gz
SYSSTAT_TARBALL=sysstat-7.0.0.tar.gz
HTTPD_TARBALL=httpd-2.0.54.tar.gz
MOD_JK_TARBALL=jakarta-tomcat-connectors-1.2.15-src.tar.gz
TOMCAT_TARBALL=apache-tomcat-5.5.17.tar.gz
MYSQL_TARBALL=mysql-5.0.51a-modified-bin.tar.gz
RUBBOS_TARBALL=RUBBoS-servlets.tar.gz
RUBBOS_DATA_TARBALL=rubbos_mod_data.tar.gz
RUBBOS_DATA_TEXTFILES_TARBALL=smallDB-rubbos-modified.tgz
MYSQL_CONNECTOR=mysql-connector-java-5.0.4-bin.jar
MYSQL_PORT=3313
MYSQL_SOCKET=$MYSQL_HOME/mysql.sock
MYSQL_DATA_DIR=$MYSQL_HOME/data
MYSQL_ERR_LOG=$MYSQL_HOME/data/mysql.log
MYSQL_PID_FILE=$MYSQL_HOME/run/mysqld.pid
MYSQL_ROOT_PW=new-password
OLDER_MYSQL=true
PUTSUDO=true
ROOT_PASSWORD=new-password
ELBA_USER=elba
ELBA_PASSWORD=elba
PUTSUDO=true

JAVA_OPTS=""


CLASSPATH=$CLASSPATH:$JONAS_ROOT/bin/unix/registry:$JAVA_HOME:$JAVA_HOME/lib/tools.jar:$CATALINA_HOME/common/lib/servlet-api.jar:.

PATH=$JAVA_HOME/bin:$JONAS_ROOT/bin/unix:$ANT_HOME/bin:$CATALINA_HOME/bin:$PATH
set +o allexport

