


#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

echo "  STOPPING TOMCAT on $HOSTNAME"

cd $CATALINA_HOME/bin
./shutdown.sh

echo "  TOMCAT IS STOPPED on $HOSTNAME"


