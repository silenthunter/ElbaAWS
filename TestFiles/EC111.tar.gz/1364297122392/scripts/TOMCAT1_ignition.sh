

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

echo "  STARTING TOMCAT on $HOSTNAME"

cd $CATALINA_HOME/bin
./startup.sh

echo "  TOMCAT IS RUNNING on $HOSTNAME"


