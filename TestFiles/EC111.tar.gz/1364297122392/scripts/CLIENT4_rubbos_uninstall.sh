

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

cd $SYSSTAT_HOME
sudo make uninstall
sudo rm -rf $SYSSTAT_HOME
sudo  rm -rf $RUBBOS_HOME
sudo  rm -rf $ELBA_TOP


