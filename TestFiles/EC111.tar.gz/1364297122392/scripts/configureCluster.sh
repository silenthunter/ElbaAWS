
    #!/bin/bash

    cd /home/ec2-user/test/rubbosMulini6/output
    source set_elba_env.sh

    
ssh $MYSQL1_HOST  /tmp/MYSQL1_ignition.sh  &
sleep 10

ssh $TOMCAT1_HOST  /tmp/TOMCAT1_ignition.sh 
sleep 10

ssh $HTTPD_HOST  /tmp/HTTPD_ignition.sh 
sleep 5
    HostName=node9
    chmod 755 /home/ec2-user/test/rubbosMulini6/output/mysql_conf/loaddb.sh
    scp -o StrictHostKeyChecking=no -o BatchMode=yes /home/ec2-user/test/rubbosMulini6/output/mysql_conf/loaddb.sh  $HostName:/tmp
    ssh $HostName /tmp/loaddb.sh
        
ssh $HTTPD_HOST  /tmp/HTTPD_stop.sh 


ssh $TOMCAT1_HOST  /tmp/TOMCAT1_stop.sh 


ssh $MYSQL1_HOST  /tmp/MYSQL1_stop.sh 

     chmod 755 /home/ec2-user/test/rubbosMulini6/output/mysql_conf/createTarBall.sh
     
