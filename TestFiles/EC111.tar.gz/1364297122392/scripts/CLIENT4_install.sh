

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

echo "  INSTALLING RUBBOS CLIENT on $HOSTNAME"

tar xzf $SOFTWARE_HOME/$JAVA_TARBALL --directory=$RUBBOS_TOP

echo "  DONE INSTALLING RUBBOS CLIENT on $HOSTNAME"


