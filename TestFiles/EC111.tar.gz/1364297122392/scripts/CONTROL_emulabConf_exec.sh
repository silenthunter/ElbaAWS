

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh


# Limit pc3000 Memory Capacity

sleep 10


# Make and mount new partiton
echo "*** make FS on a partition and mount it *************************"

for i in "$BENCHMARK_HOST" "$CLIENT1_HOST" "$CLIENT2_HOST" "$CLIENT3_HOST" "$CLIENT4_HOST" "$HTTPD_HOST" "$TOMCAT1_HOST" "$MYSQL1_HOST"
do
ssh $i "
  sudo mkdir -p $ELBA_TOP
  sudo chmod 777 $ELBA_TOP
"
scp $WORK_HOME/emulab_files/limits.conf $i:$ELBA_TOP
scp $WORK_HOME/emulab_files/login $i:$ELBA_TOP
scp $WORK_HOME/emulab_files/file-max $i:$ELBA_TOP

ssh $i "
  sudo mv $ELBA_TOP/limits.conf /etc/security/
  sudo mv $ELBA_TOP/login  /etc/pam.d/
"
done



for i in "$BENCHMARK_HOST" "$CLIENT1_HOST" "$CLIENT2_HOST" "$CLIENT3_HOST" "$CLIENT4_HOST" "$HTTPD_HOST" "$TOMCAT1_HOST" "$MYSQL1_HOST"
do
  ssh $i "
    sudo mkdir -p $ELBA_TOP
    echo -e \"t\n4\n83\nw\" | sudo /sbin/fdisk /dev/sda
    sudo reboot
  " &
done

echo "sleep 480"
sleep 480
echo "wake up from sleeping 480"


for i in "$BENCHMARK_HOST" "$CLIENT1_HOST" "$CLIENT2_HOST" "$CLIENT3_HOST" "$CLIENT4_HOST" "$HTTPD_HOST" "$TOMCAT1_HOST" "$MYSQL1_HOST"
do
  ssh $i "
   sudo /sbin/mkfs /dev/sda4 
   sudo mount /dev/sda4 $ELBA_TOP 
   sudo chmod 777 $ELBA_TOP
   mkdir -p $RUBBOS_TOP
   sudo cp $SOFTWARE_HOME/sdparm-1.03.tgz /tmp
   cd /tmp
   sudo tar -zxvf ./sdparm-1.03.tgz
   cd sdparm-1.03
   sudo ./configure
   sudo make
   sudo make install
   sudo sdparm -c WCE /dev/sda
  " &
done

echo "sleep 420"
sleep 420
echo "wake up from sleeping 420"


# Turning off Swap Partition

sleep 10



