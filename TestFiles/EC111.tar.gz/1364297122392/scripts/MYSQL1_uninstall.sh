


#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

sudo  rm -rf $MYSQL_HOME
sudo  rm -rf $ELBA_TOP


