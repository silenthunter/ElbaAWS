

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

export JAVA_OPTS=-Xmx160m

echo "  INSTALLING MYSQL on $HOSTNAME"

mkdir -p $ELBA_TOP
chmod 755 $ELBA_TOP
mkdir -p $RUBBOS_TOP
chmod 755 $RUBBOS_TOP


tar xzf $SOFTWARE_HOME/$MYSQL_TARBALL --directory=$RUBBOS_TOP 
  
cd $MYSQL_HOME
sudo  scripts/mysql_install_db --no-defaults --basedir=$MYSQL_HOME --port=$MYSQL_PORT --datadir=$MYSQL_DATA_DIR --log=$MYSQL_ERR_LOG --pid-file=$MYSQL_PID_FILE --socket=$MYSQL_SOCKET
            

    echo "COPYING DATA to Local_Disk"
    cp -v $DATA_HOME/$RUBBOS_DATA_TARBALL $MYSQL_HOME
 
echo "  DONE INSTALLING MYSQL on $HOSTNAME"



