

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

export JAVA_OPTS=-Xmx160m

echo "  RESETING MYSQL on $HOSTNAME"
# copy rubbos data files

sudo tar xvzf $SOFTWARE_HOME/$RUBBOS_DATA_TARBALL --directory=$MYSQL_HOME/data/rubbos
 

echo "  DONE RESETING MYSQL on $HOSTNAME"
sleep 5


