

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

echo "  CONFIGURING RUBBOS SERVLET on $HOSTNAME"

\cp $OUTPUT_HOME/rubbos_conf/build.properties $RUBBOS_HOME/

\cp -r $WORK_HOME/rubbos_files/Servlets $RUBBOS_HOME/

\cp $OUTPUT_HOME/rubbos_conf/mysql.properties $RUBBOS_HOME/Servlets/

\cp $OUTPUT_HOME/rubbos_conf/build.xml $RUBBOS_HOME/Servlets/
\cp $OUTPUT_HOME/rubbos_conf/Config.java /mnt/elba/rubbos/RUBBoS/Servlets/edu/rice/rubbos/servlets/
\cp $OUTPUT_HOME/rubbos_conf/web.xml $RUBBOS_HOME/Servlet_HTML/WEB-INF/

cd $RUBBOS_HOME/Servlets/edu/rice/rubbos/servlets
sed 's/public static final int    BrowseCategoriesPoolSize      = 6;/public static final int    BrowseCategoriesPoolSize      = 24;/g' Config.java > Config.java.tmp
\mv Config.java.tmp Config.java


cd $RUBBOS_HOME/Servlets
ant clean
ant dist
#make
\cp rubbos.war $CATALINA_HOME/webapps/

echo "  DONE CONFIGURING RUBBOS SERVLET on $HOSTNAME"







