

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

rm -rf $JAVA_HOME
rm -rf $ELBA_TOP


