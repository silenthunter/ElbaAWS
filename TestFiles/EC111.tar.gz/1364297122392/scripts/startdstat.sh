
#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

for i in "$BENCHMARK_HOST" "$CLIENT1_HOST" "$CLIENT2_HOST" "$CLIENT3_HOST" "$CLIENT4_HOST" "$HTTPD_HOST" "$TOMCAT1_HOST" "$MYSQL1_HOST"
do
  ssh $i rm -rf /tmp/$i.csv
  ssh $i $ELBA_TOP/rubbos/dstat/dstat -c -d -i -m -n -p -r -y --vm --no --output /tmp/$i.csv 1 &
  
done
