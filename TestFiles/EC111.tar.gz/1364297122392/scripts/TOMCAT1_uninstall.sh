


#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

rm -rf $CATALINA_HOME
rm -rf $ELBA_TOP


