

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

export JAVA_OPTS=-Xmx160m

echo "  STARTING MYSQL on $HOSTNAME"

cd $MYSQL_HOME
    sudo  bin/mysqld_safe --defaults-file="$MYSQL_HOME/my.cnf" --datadir=$MYSQL_DATA_DIR --pid-file=$MYSQL_PID_FILE --socket=$MYSQL_SOCKET --port=$MYSQL_PORT --user=root --log-bin=rubbos-bin --max_connections=500 &
      


echo "  MYSQL IS RUNNING on $HOSTNAME"


