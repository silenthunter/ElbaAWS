
#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh


ssh $MYSQL1_HOST  /tmp/MYSQL1_ignition.sh  &
sleep 10

ssh $TOMCAT1_HOST  /tmp/TOMCAT1_ignition.sh 
sleep 10

ssh $HTTPD_HOST  /tmp/HTTPD_ignition.sh 
sleep 5
