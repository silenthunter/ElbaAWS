


#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

export JAVA_OPTS=-Xmx160m

echo "  STOPPING MYSQL on $HOSTNAME"

cd $MYSQL_HOME
bin/mysqladmin --socket=$MYSQL_SOCKET  --user=root --password=$ROOT_PASSWORD shutdown

echo "  MYSQL IS STOPPED on $HOSTNAME"


