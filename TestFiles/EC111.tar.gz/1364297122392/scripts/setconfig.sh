
#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh


for i in "node1" "node2" "node3" "node4" "node5" "node6" "node7" "node8" "node9"
do
ssh $i "
hostname $i
hostname
sudo sysctl -w net.core.rmem_max=8388608
sudo sysctl -w net.core.wmem_max=8388608
sudo sysctl -w net.core.rmem_default=65536
sudo sysctl -w net.core.wmem_default=65536
sudo sysctl -w net.ipv4.tcp_mem='8388608 8388608 8388608'
sudo sysctl -w net.ipv4.tcp_rmem='4096 87380 8388608'
sudo sysctl -w net.ipv4.tcp_wmem='4096 65536 8388608'
sudo sysctl -w net.ipv4.route.flush=1
"
done
