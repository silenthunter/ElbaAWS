
#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh

 

ssh $MYSQL1_HOST  /tmp/MYSQL1_reset.sh 
 


#sleep 30

