

#!/bin/bash

cd /home/ec2-user/test/rubbosMulini6/output
source set_elba_env.sh


echo "Starting RUBBoS"
chmod 777 $OUTPUT_HOME/updatedb
$OUTPUT_HOME/updatedb.sh 1
ssh $RUBBOS_RESULTS_HOST "
  mkdir -p $RUBBOS_RESULTS_DIR_BASE
"
ssh $BENCHMARK_HOST "
  mkdir -p $TMP_RESULTS_DIR_BASE/$RUBBOS_RESULTS_DIR_NAME
"
for j in "1000"
do
  i=rubbos.properties_$j
  $OUTPUT_HOME/updatedb.sh 3 $j-RO
  ssh $BENCHMARK_HOST "
    source /home/ec2-user/test/rubbosMulini6/output/set_elba_env.sh
    rm -f $RUBBOS_HOME/Client/rubbos.properties*
  "
  
  scp $OUTPUT_HOME/rubbos_conf/$i $BENCHMARK_HOST:$RUBBOS_HOME/Client/rubbos.properties
  

  echo "Resetting all data"
  $OUTPUT_HOME/scripts/reset_all.sh

  # Browsing Only
  echo "Start Browsing Only with $i"
  echo "Removing previous logs..."
  ssh $HTTPD_HOST "rm -f $HTTPD_HOME/logs/*log"
  ssh $TOMCAT1_HOST "rm -f $CATALINA_HOME/logs/*"
  ssh $MYSQL1_HOST "rm -f $MYSQL_HOME/run/*.log $RUBBOS_TOP/mysql_mon-*"

  $OUTPUT_HOME/scripts/start_all.sh

  sleep 15
    ssh $BENCHMARK_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT1_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT2_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT3_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT4_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $HTTPD_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $TOMCAT1_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $MYSQL1_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"

  ssh $BENCHMARK_HOST "
    source /home/ec2-user/test/rubbosMulini6/output/set_elba_env.sh
    cd $RUBBOS_HOME/bench
    \rm -r 20*

    # Execute benchmark
    ./rubbos-servletsBO.sh

    # Collect results
    echo "The benchmark has finished. Now, collecting results..."
    cd 20*

    scp $HTTPD_HOST:$HTTPD_HOME/logs/access_log ./HTTPD_access.log
    scp $HTTPD_HOST:$HTTPD_HOME/logs/mod_jk.log ./HTTPD_modjk.log
    gzip HTTPD_access.log
    gzip HTTPD_modjk.log
    scp $BENCHMARK_HOST:$RUBBOS_TOP/sar-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/ps-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/iostat-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/dstat-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $BENCHMARK_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $BENCHMARK_HOST:/tmp/*.csv ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $CLIENT1_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT1_HOST:/tmp/*.csv ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $CLIENT2_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT2_HOST:/tmp/*.csv ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $CLIENT3_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT3_HOST:/tmp/*.csv ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $CLIENT4_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT4_HOST:/tmp/*.csv ./
    scp $HTTPD_HOST:$RUBBOS_TOP/sar-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/ps-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/iostat-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/dstat-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $HTTPD_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $HTTPD_HOST:/tmp/*.csv ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/sar-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/ps-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/iostat-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/dstat-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $TOMCAT1_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $TOMCAT1_HOST:/tmp/*.csv ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/sar-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/ps-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/iostat-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/dstat-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/mysql_mon-* ./
     scp $MYSQL1_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $MYSQL1_HOST:/tmp/*.csv ./

    scp $HTTPD_HOST:$HTTPD_HOME/logs/*log ./
    scp $TOMCAT_1_HOST:$CATALINA_HOME/logs/*log ./
    cd ..
    mv 20* $TMP_RESULTS_DIR_BASE/$RUBBOS_RESULTS_DIR_NAME/$j-RO
  "
  $OUTPUT_HOME/scripts/stop_all.sh
  sleep 15
  echo "End Browsing Only with $i"

  # Read/Write
  echo "Start Read/Write with $i"
  $OUTPUT_HOME/updatedb.sh 3 $j-RW
  echo "Removing previous logs"
  ssh $HTTPD_HOST "rm -f $HTTPD_HOME/logs/*log"
  ssh $TOMCAT1_HOST "rm -f $CATALINA_HOME/logs/*"
  ssh $MYSQL1_HOST "rm -f $MYSQL_HOME/run/*.log $RUBBOS_TOP/mysql_mon-*"

  $OUTPUT_HOME/scripts/start_all.sh
  
  sleep 15
    ssh $BENCHMARK_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT1_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT2_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT3_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $CLIENT4_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $HTTPD_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $TOMCAT1_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"
  ssh $MYSQL1_HOST "rm -f $RUBBOS_TOP/sar-* $RUBBOS_TOP/ps-* $RUBBOS_TOP/iostat-* $RUBBOS_TOP/dstat-*"

  ssh $BENCHMARK_HOST "
    source /home/ec2-user/test/rubbosMulini6/output/set_elba_env.sh
    cd $RUBBOS_HOME/bench
    \rm -r 20*

    # Execute benchmark
    ./rubbos-servletsRW.sh

    # Collect results
    echo "The benchmark has finished. Now, collecting results..."
    cd 20*

    scp $HTTPD_HOST:$HTTPD_HOME/logs/access_log ./HTTPD_access.log
    scp $HTTPD_HOST:$HTTPD_HOME/logs/mod_jk.log ./HTTPD_modjk.log
    gzip HTTPD_access.log
    gzip HTTPD_modjk.log

    scp $BENCHMARK_HOST:$RUBBOS_TOP/sar-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/ps-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/iostat-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/dstat-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $BENCHMARK_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $BENCHMARK_HOST:/tmp/*.csv ./

    scp $CLIENT1_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $CLIENT1_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT1_HOST:/tmp/*.csv ./

    scp $CLIENT2_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $CLIENT2_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT2_HOST:/tmp/*.csv ./

    scp $CLIENT3_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $CLIENT3_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT3_HOST:/tmp/*.csv ./

    scp $CLIENT4_HOST:$RUBBOS_TOP/sar-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/ps-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/iostat-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/dstat-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $CLIENT4_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $CLIENT4_HOST:/tmp/*.csv ./

    scp $HTTPD_HOST:$RUBBOS_TOP/sar-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/ps-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/iostat-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/dstat-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $HTTPD_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $HTTPD_HOST:/tmp/*.csv ./

    scp $TOMCAT1_HOST:$RUBBOS_TOP/sar-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/ps-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/iostat-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/dstat-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $TOMCAT1_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $TOMCAT1_HOST:/tmp/*.csv ./

    scp $MYSQL1_HOST:$RUBBOS_TOP/sar-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/ps-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/iostat-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/dstat-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/mysql_mon-* ./
    scp $MYSQL1_HOST:$RUBBOS_TOP/postgres_lock-* ./
    scp $MYSQL1_HOST:/tmp/*.csv ./

    scp $HTTPD_HOST:$HTTPD_HOME/logs/*log ./
    scp $TOMCAT_1_HOST:$CATALINA_HOME/logs/*log ./
    cd ..
    mv 20* $TMP_RESULTS_DIR_BASE/$RUBBOS_RESULTS_DIR_NAME/$j-RW
  "

  $OUTPUT_HOME/scripts/stop_all.sh
  sleep 15
  echo "End Read/Write with $i"

done

echo "Processing the results..."
ssh $BENCHMARK_HOST "
  cd $TMP_RESULTS_DIR_BASE
  cd $RUBBOS_RESULTS_DIR_NAME
  scp $RUBBOS_RESULTS_HOST:$RUBBOS_RESULTS_PARSE/calc-sarSummary.prl ../
  ../calc-sarSummary.prl

  scp $RUBBOS_RESULTS_HOST:$RUBBOS_RESULTS_PARSE/calc-durationTime.prl ../

  ../calc-durationTime.prl

  rm -f 20*/*.bin

  cd ../
  tar zcvf $RUBBOS_RESULTS_DIR_NAME.tgz $RUBBOS_RESULTS_DIR_NAME
  scp $RUBBOS_RESULTS_DIR_NAME.tgz $RUBBOS_RESULTS_HOST:$RUBBOS_RESULTS_DIR_BASE/
"

echo "Finish RUBBoS"
$OUTPUT_HOME/updatedb.sh 2









