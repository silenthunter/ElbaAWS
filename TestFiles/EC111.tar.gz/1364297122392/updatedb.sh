#!/bin/sh
#
# Script to see whether argument is positive or negative
#
expname='EC2Test'
username='ggresham3'
cloud='ec2'
application='rubbos'
url="http://expertus.cc.gatech.edu:8080/axis2/services/ExpertusService"
data="none"
fd=file.txt
while read line; do data="$line"; done < $fd
if [ "$data" == "none" ]
then
   TIMESTAMP=$(date +%m%d%y%H%M%S-$RANDOM)
data="$TIMESTAMP"
fi
if test $1 -eq 1
then
    url="$url/startExperiment?name=$expname&user=$username&application=$application&cloud=$cloud&id=$data"
echo "$data" > $fd
elif test $1 -eq 2
then
url="$url/stopExperiment?id=$data"
rm $fd
else
url="$url/startWorkload?id=$data&workload=$2"
fi
curl $url
